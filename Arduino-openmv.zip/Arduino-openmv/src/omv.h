

#ifndef __OMV_H__
#define __OMV_H__

#include "stdbool.h"
#include "stdint.h"

bool omv_init();
bool omv_init_once();

#endif
