
extern "C" {
#include "imlib.h"

}
